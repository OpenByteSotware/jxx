#include <algorithm>
#include <string>

#include <openssl/bio.h>
#include <openssl/err.h>
#include <openssl/ssl.h>
#include "ext/net/ssl/internal/jxx.ext.net.ssl.internal.OpenSslEngine.h"
#include "ext/net/ssl/internal/jxx.ext.net.ssl.internal.OpenSslContextConfig.h"
#include "ext/net/ssl/internal/jxx.ext.net.ssl.internal.OpenSslCompatibility.h"
#include "ext/net/ssl/internal/jxx.ext.net.ssl.internal.OpenSslCipherSuites.h"
#include "ext/net/ssl/internal/jxx.ext.net.ssl.internal.OpenSslManagerBridge.h"
#include "ext/net/ssl/internal/jxx.ext.net.ssl.internal.OpenSslSniMatcher.h"
#include "ext/net/ssl/internal/jxx.ext.net.ssl.internal.OpenSslProtocolPolicy.h"
#include "ext/net/ssl/internal/jxx.ext.net.ssl.internal.OpenSslPeerIdentity.h"
#include "ext/net/ssl/internal/jxx.ext.net.ssl.internal.OpenSslSession.h"
#include "ext/net/ssl/internal/jxx.ext.net.ssl.internal.OpenSslSignatureAlgorithms.h"
#include "ext/net/ssl/internal/jxx.ext.net.ssl.internal.OpenSslSessionContext.h"
#include "ext/net/ssl/internal/jxx.ext.net.ssl.internal.OpenSslServerSessionCache.h"
#include "ext/net/ssl/jxx.ext.net.ssl.SSLHandshakeException.h"
#include "ext/net/ssl/jxx.ext.net.ssl.SSLParameters.h"
#include "ext/net/ssl/jxx.ext.net.ssl.SNIHostName.h"
#include "ext/net/ssl/internal/jxx.ext.net.ssl.internal.OpenSslX509Certificate.h"
#include "util/jxx.util.ArrayList.h"
#include <openssl/x509.h>
#include "ext/net/ssl/jxx.ext.net.ssl.SSLPeerUnverifiedException.h"
#include "ext/net/ssl/jxx.ext.net.ssl.SSLProtocolException.h"
#include "lang/jxx.lang.IllegalArgumentException.h"
#include "lang/jxx.lang.IllegalStateException.h"
#include "lang/jxx.lang.NullPointerException.h"
#include "nio/jxx.nio.ByteBuffer.h"

namespace jxx::ext::net::ssl::internal {
namespace {

::jxx::Ptr<SSLEngineResult> result(
    SSLEngineResult::Status status,
    SSLEngineResult::HandshakeStatus handshake,
    ::jxx::lang::jint consumed,
    ::jxx::lang::jint produced) {
    return ::jxx::NEW<SSLEngineResult>(
        status, handshake, consumed, produced);
}

std::string join(const std::vector<std::string>& values) {
    std::string joined;
    for (const auto& value : values) {
        if (!joined.empty()) joined.push_back(':');
        joined += value;
    }
    return joined;
}

} // namespace

OpenSslEngine::OpenSslEngine(
    const std::shared_ptr<OpenSslContextConfig>& config,
    const ::jxx::Ptr<::jxx::lang::String>& peerHost,
    ::jxx::lang::jint peerPort)
    : Super(peerHost, peerPort)
    , config_(config) {
    if (peerPort < -1 || peerPort > 65535)
        throw ::jxx::lang::IllegalArgumentException();
    enabledProtocols_ = contextProtocolNames(
        config_ == nullptr ? nullptr : config_->protocol);
}

OpenSslEngine::~OpenSslEngine() {
    if (ssl_ != nullptr) {
        SSL_free(ssl_);
        ssl_ = nullptr;
        inboundBio_ = nullptr;
        outboundBio_ = nullptr;
    }
    if (context_ != nullptr) {
        SSL_CTX_free(context_);
        context_ = nullptr;
    }
}

void OpenSslEngine::ensureInitialized() {
    if (initialized_) return;
    context_ = SSL_CTX_new(TLS_method());
    if (context_ == nullptr)
        throw ::jxx::ext::net::ssl::SSLProtocolException(
            "SSL_CTX_new failed");
    applyEnabledProtocols(context_, enabledProtocols_);

    if (!enabledCipherSuites_.empty())
        applyEnabledCipherSuites(context_, enabledCipherSuites_);

    if (!clientMode_ && config_ != nullptr && config_->serverSessionContext != nullptr)
        configureServerSessionCache(
            context_, config_->serverSessionContext.get());
    if (!clientMode_ && !enableSessionCreation_) {
        SSL_CTX_set_session_cache_mode(context_, SSL_SESS_CACHE_OFF);
        SSL_CTX_set_options(context_, SSL_OP_NO_TICKET);
    }
    managerBridge_ = std::make_unique<OpenSslManagerBridge>(config_, algorithmConstraints_);
    SSL_CTX_set_cert_verify_callback(
        context_, openSslVerifyCallback, managerBridge_.get());
    SSL_CTX_set_client_cert_cb(context_, openSslClientCertificateCallback);
    if (!clientMode_) configureServerNameMatchers(context_, sniMatchers_);
    SSL_CTX_set_default_verify_paths(context_);

    if (!clientMode_ && useCipherSuitesOrder_)
        SSL_CTX_set_options(
            context_,
            SSL_OP_CIPHER_SERVER_PREFERENCE);

    ssl_ = SSL_new(context_);
    if (ssl_ == nullptr)
        throw ::jxx::ext::net::ssl::SSLProtocolException("SSL_new failed");
    inboundBio_ = BIO_new(BIO_s_mem());
    outboundBio_ = BIO_new(BIO_s_mem());
    if (inboundBio_ == nullptr || outboundBio_ == nullptr)
        throw ::jxx::ext::net::ssl::SSLProtocolException(
            "memory BIO allocation failed");
    BIO_set_mem_eof_return(inboundBio_, -1);
    BIO_set_mem_eof_return(outboundBio_, -1);
    SSL_set_bio(ssl_, inboundBio_, outboundBio_);
    SSL_set_ex_data(
        ssl_, openSslManagerBridgeExDataIndex(), managerBridge_.get());

    if (clientMode_) {
        SSL_set_connect_state(ssl_);
        if (config_ != nullptr && config_->clientSessionContext != nullptr) {
            SSL_SESSION* cached = config_->clientSessionContext->acquireNativeSession(
                getPeerHost(), getPeerPort());
            if (cached != nullptr) {
                const int applied = SSL_set_session(ssl_, cached);
                SSL_SESSION_free(cached);
                if (applied != 1)
                    throw ::jxx::ext::net::ssl::SSLProtocolException(
                        "could not apply cached TLS session");
            }
        }
        const auto peerHost = getPeerHost();
        const auto sniHost = explicitSniHost_ != nullptr ? explicitSniHost_ : peerHost;
        if (sniHost != nullptr && !sniHost->utf8().empty() && SSL_set_tlsext_host_name(ssl_, sniHost->utf8().c_str()) != 1)
            throw ::jxx::ext::net::ssl::SSLProtocolException("could not configure SNI host");
        if (endpointIdentificationAlgorithm_ != nullptr && endpointIdentificationAlgorithm_->utf8() == "HTTPS")
            configureHttpsEndpointIdentification(ssl_, peerHost);
    } else {
        SSL_set_accept_state(ssl_);
        int verifyMode = SSL_VERIFY_NONE;
        if (needClientAuth_)
            verifyMode = SSL_VERIFY_PEER | SSL_VERIFY_FAIL_IF_NO_PEER_CERT;
        else if (wantClientAuth_)
            verifyMode = SSL_VERIFY_PEER;
        SSL_set_verify(ssl_, verifyMode, nullptr);
        if (managerBridge_->selectServerIdentity(ssl_) != 1)
            throw ::jxx::ext::net::ssl::SSLHandshakeException(
                "no usable server certificate identity");
    }
    initialized_ = true;
}

void OpenSslEngine::beginHandshake() {
    ensureInitialized();
    if (inboundDone_ || outboundDone_)
        throw ::jxx::lang::IllegalStateException(
            "cannot handshake a closed SSL engine");
    if (handshakeActive_)
        throw ::jxx::lang::IllegalStateException(
            "handshake already in progress");

    handshakeFinishedReported_ = false;
    if (!initialHandshakeStarted_) {
        initialHandshakeStarted_ = true;
        handshakeActive_ = true;
        driveHandshake();
        return;
    }

#ifdef TLS1_3_VERSION
    if (SSL_version(ssl_) >= TLS1_3_VERSION)
        throw ::jxx::ext::net::ssl::SSLHandshakeException(
            "TLS 1.3 does not support renegotiation");
#endif
    if (!beginRenegotiation(ssl_))
        throw ::jxx::ext::net::ssl::SSLHandshakeException(
            "TLS renegotiation could not be started");

    if (!clientMode_) {
        int verifyMode = SSL_VERIFY_NONE;
        if (needClientAuth_)
            verifyMode = SSL_VERIFY_PEER | SSL_VERIFY_FAIL_IF_NO_PEER_CERT;
        else if (wantClientAuth_)
            verifyMode = SSL_VERIFY_PEER;
        SSL_set_verify(ssl_, verifyMode, nullptr);
    }
    handshakeActive_ = true;
    handshakeStatus_ = SSLEngineResult::HandshakeStatus::NEED_WRAP;
    driveHandshake();
}

void OpenSslEngine::driveHandshake() {
    if (!handshakeActive_) return;
    const int operation = SSL_do_handshake(ssl_);
    if (operation == 1) {
        handshakeStatus_ = SSLEngineResult::HandshakeStatus::FINISHED;
        handshakeActive_ = false;
        completeSession();
        return;
    }
    const int error = SSL_get_error(ssl_, operation);
    updateHandshakeStatus(error);
}

void OpenSslEngine::updateHandshakeStatus(int error) {
    if (BIO_ctrl_pending(outboundBio_) > 0) {
        handshakeStatus_ = SSLEngineResult::HandshakeStatus::NEED_WRAP;
        return;
    }
    if (error == SSL_ERROR_WANT_READ) {
        handshakeStatus_ = SSLEngineResult::HandshakeStatus::NEED_UNWRAP;
        return;
    }
    if (error == SSL_ERROR_WANT_WRITE) {
        handshakeStatus_ = SSLEngineResult::HandshakeStatus::NEED_WRAP;
        return;
    }
    throw ::jxx::ext::net::ssl::SSLHandshakeException(
        "OpenSSL handshake failed");
}

void OpenSslEngine::completeSession() {
    if (session_ != nullptr) return;
    if (!enableSessionCreation_ && !SSL_session_reused(ssl_))
        throw ::jxx::ext::net::ssl::SSLHandshakeException(
            "session creation is disabled");
    SSL_SESSION* nativeSession = SSL_get_session(ssl_);
    if (clientMode_ && nativeSession != nullptr && config_ != nullptr &&
        config_->clientSessionContext != nullptr)
        config_->clientSessionContext->registerNativeSession(
            getPeerHost(), getPeerPort(), nativeSession);
    unsigned int idLength = 0;
    const unsigned char* id = nativeSession == nullptr
        ? nullptr
        : SSL_SESSION_get_id(nativeSession, &idLength);
    const auto sessionId = ::jxx::NEW<
        ::jxx::lang::JxxArray<::jxx::lang::jbyte, 1U>>(
            static_cast<::jxx::lang::jint>(idLength));
    for (unsigned int index = 0; index < idLength; ++index)
        (*sessionId)[static_cast<::jxx::lang::jint>(index)] =
            static_cast<::jxx::lang::jbyte>(id[index]);
    using CertificateArray = OpenSslSession::CertificateArray;
    const auto peerCertificates = peerCertificateChain(ssl_);
    ::jxx::Ptr<CertificateArray> localCertificates;
    X509* local = SSL_get_certificate(ssl_);
    if (local != nullptr) {
        const int length = i2d_X509(local, nullptr);
        const auto encoded = ::jxx::NEW<
            ::jxx::lang::JxxArray<::jxx::lang::jbyte, 1U>>(length);
        unsigned char* cursor = reinterpret_cast<unsigned char*>(&(*encoded)[0]);
        if (length <= 0 || i2d_X509(local, &cursor) != length)
            throw ::jxx::ext::net::ssl::SSLProtocolException(
                "could not encode local certificate");
        localCertificates = ::jxx::NEW<CertificateArray>(1);
        (*localCertificates)[0] = ::jxx::CAST<
            ::jxx::security::cert::Certificate>(
                ::jxx::NEW<OpenSslX509Certificate>(encoded));
    }
    const auto context = clientMode_
        ? config_->clientSessionContext
        : config_->serverSessionContext;
    session_ = ::jxx::NEW<OpenSslSession>(
        ::jxx::NEW<::jxx::lang::String>(SSL_get_cipher_name(ssl_)),
        ::jxx::NEW<::jxx::lang::String>(SSL_get_version(ssl_)),
        getPeerHost(), getPeerPort(), peerCertificates,
        localCertificates, sessionId, context,
        localSupportedSignatureAlgorithms(ssl_),
        peerSupportedSignatureAlgorithms(ssl_),
        requestedServerNames(ssl_));
    if (context != nullptr) context->registerSession(session_);
}

::jxx::lang::jint OpenSslEngine::feedNetwork(
    const ::jxx::Ptr<::jxx::nio::ByteBuffer>& source) {
    if (source == nullptr) throw ::jxx::lang::NullPointerException();

    // SSLEngine must leave an incomplete TLS record in the caller's buffer.
    // Determine the complete-record prefix without changing source.position().
    const auto available = source->remaining();
    const auto start = source->position();
    ::jxx::lang::jint accepted = 0;
    while (available - accepted >= 5) {
        const auto high = static_cast<unsigned char>(
            source->get(start + accepted + 3));
        const auto low = static_cast<unsigned char>(
            source->get(start + accepted + 4));
        const auto payloadLength = static_cast<::jxx::lang::jint>(
            (static_cast<unsigned int>(high) << 8U) |
            static_cast<unsigned int>(low));
        const auto recordLength = static_cast<::jxx::lang::jint>(5) +
            payloadLength;
        if (recordLength > available - accepted) break;
        accepted += recordLength;
    }
    if (accepted == 0) return 0;

    std::vector<unsigned char> data(static_cast<std::size_t>(accepted));
    for (::jxx::lang::jint index = 0; index < accepted; ++index)
        data[static_cast<std::size_t>(index)] =
            static_cast<unsigned char>(source->get(start + index));

    const int written = BIO_write(inboundBio_, data.data(), accepted);
    if (written <= 0)
        throw ::jxx::ext::net::ssl::SSLProtocolException(
            "could not feed encrypted input");

    // Commit only bytes accepted by the BIO. Memory BIOs normally accept the
    // complete prefix, but honoring a short write keeps accounting exact.
    for (int index = 0; index < written; ++index) source->get();
    return static_cast<::jxx::lang::jint>(written);
}

::jxx::lang::jint OpenSslEngine::drainNetwork(
    const ::jxx::Ptr<::jxx::nio::ByteBuffer>& destination) {
    if (destination == nullptr) throw ::jxx::lang::NullPointerException();
    const auto pending = static_cast<::jxx::lang::jint>(
        BIO_ctrl_pending(outboundBio_));
    if (pending == 0) return 0;
    if (destination->remaining() < pending) return -1;
    std::vector<unsigned char> data(static_cast<std::size_t>(pending));
    const int read = BIO_read(outboundBio_, data.data(), pending);
    if (read < 0) return 0;
    for (int index = 0; index < read; ++index)
        destination->put(static_cast<::jxx::lang::jbyte>(data[index]));
    return read;
}

::jxx::Ptr<SSLEngineResult> OpenSslEngine::wrap(
    const ::jxx::Ptr<::jxx::nio::ByteBuffer>& source,
    const ::jxx::Ptr<::jxx::nio::ByteBuffer>& destination) {
    if (source == nullptr || destination == nullptr)
        throw ::jxx::lang::NullPointerException();
    ensureInitialized();
    if (!initialHandshakeStarted_) beginHandshake();

    const auto pending = static_cast<::jxx::lang::jint>(
        BIO_ctrl_pending(outboundBio_));
    if (pending > destination->remaining())
        return result(SSLEngineResult::Status::BUFFER_OVERFLOW,
                      handshakeStatus_, 0, 0);

    ::jxx::lang::jint consumed = 0;
    if (SSL_is_init_finished(ssl_) && source->remaining() > 0) {
        const auto count = source->remaining();
        std::vector<unsigned char> plain(static_cast<std::size_t>(count));
        for (::jxx::lang::jint index = 0; index < count; ++index)
            plain[static_cast<std::size_t>(index)] =
                static_cast<unsigned char>(source->get(index + source->position()));
        const int written = SSL_write(ssl_, plain.data(), count);
        if (written > 0) {
            for (int index = 0; index < written; ++index) source->get();
            consumed = written;
        } else {
            updateHandshakeStatus(SSL_get_error(ssl_, written));
        }
    } else {
        driveHandshake();
    }

    const auto produced = drainNetwork(destination);
    if (produced < 0)
        return result(SSLEngineResult::Status::BUFFER_OVERFLOW,
                      handshakeStatus_, 0, 0);
    const auto status = outboundDone_
        ? SSLEngineResult::Status::CLOSED
        : SSLEngineResult::Status::OK;
    auto reported = handshakeStatus_;
    if (reported == SSLEngineResult::HandshakeStatus::FINISHED) {
        handshakeFinishedReported_ = true;
    } else if (handshakeFinishedReported_) {
        reported = SSLEngineResult::HandshakeStatus::NOT_HANDSHAKING;
    }
    return result(status, reported, consumed, produced);
}

::jxx::Ptr<SSLEngineResult> OpenSslEngine::unwrap(
    const ::jxx::Ptr<::jxx::nio::ByteBuffer>& source,
    const ::jxx::Ptr<::jxx::nio::ByteBuffer>& destination) {
    if (source == nullptr || destination == nullptr)
        throw ::jxx::lang::NullPointerException();
    ensureInitialized();
    if (!initialHandshakeStarted_) beginHandshake();

    const bool applicationDataExpected =
        SSL_is_init_finished(ssl_) != 0;
    const auto requiredApplicationCapacity =
        session_ == nullptr
            ? static_cast<::jxx::lang::jint>(16384)
            : session_->getApplicationBufferSize();

    if (applicationDataExpected &&
        source->remaining() > 0 &&
        destination->remaining() <
            requiredApplicationCapacity)
    {
        return result(
            SSLEngineResult::Status::BUFFER_OVERFLOW,
            handshakeStatus_,
            0,
            0);
    }

    const auto consumed = feedNetwork(source);
    if (!SSL_is_init_finished(ssl_)) driveHandshake();

    ::jxx::lang::jint produced = 0;
    if (SSL_is_init_finished(ssl_)) {
        if (destination->remaining() == 0) {
            return result(SSLEngineResult::Status::BUFFER_OVERFLOW,
                          handshakeStatus_, consumed, 0);
        }
        std::vector<unsigned char> plain(
            static_cast<std::size_t>(destination->remaining()));
        const int read = SSL_read(
            ssl_, plain.data(), static_cast<int>(plain.size()));
        if (read > 0) {
            for (int index = 0; index < read; ++index)
                destination->put(
                    static_cast<::jxx::lang::jbyte>(plain[index]));
            produced = read;
        } else {
            const int error = SSL_get_error(ssl_, read);
            if (error == SSL_ERROR_ZERO_RETURN) inboundDone_ = true;
            else if (error != SSL_ERROR_WANT_READ)
                throw ::jxx::ext::net::ssl::SSLProtocolException(
                    "OpenSSL unwrap failed");
        }
    }

    if (consumed == 0 && produced == 0 &&
        handshakeStatus_ == SSLEngineResult::HandshakeStatus::NEED_UNWRAP)
        return result(SSLEngineResult::Status::BUFFER_UNDERFLOW,
                      handshakeStatus_, 0, 0);
    return result(inboundDone_ ? SSLEngineResult::Status::CLOSED
                               : SSLEngineResult::Status::OK,
                  handshakeStatus_, consumed, produced);
}

::jxx::Ptr<SSLEngineResult> OpenSslEngine::wrap(
    const ::jxx::Ptr<ByteBufferArray>& sources,
    ::jxx::lang::jint offset,
    ::jxx::lang::jint length,
    const ::jxx::Ptr<::jxx::nio::ByteBuffer>& destination) {
    if (sources == nullptr) throw ::jxx::lang::NullPointerException();
    if (destination == nullptr) throw ::jxx::lang::NullPointerException();
    if (offset < 0 || length < 0 || offset > sources->length - length)
        throw ::jxx::lang::IllegalArgumentException();

    ::jxx::lang::jint total = 0;
    for (::jxx::lang::jint index = offset; index < offset + length; ++index) {
        const auto source = (*sources)[index];
        if (source == nullptr) throw ::jxx::lang::NullPointerException();
        total += source->remaining();
    }

    const auto gathered = ::jxx::nio::ByteBuffer::allocate(total);
    for (::jxx::lang::jint index = offset; index < offset + length; ++index) {
        const auto source = (*sources)[index];
        const auto position = source->position();
        for (::jxx::lang::jint cursor = 0; cursor < source->remaining(); ++cursor)
            gathered->put(source->get(position + cursor));
    }
    gathered->flip();

    const auto wrapped = wrap(gathered, destination);
    auto remainingConsumed = wrapped->bytesConsumed();
    for (::jxx::lang::jint index = offset;
         index < offset + length && remainingConsumed > 0;
         ++index) {
        const auto source = (*sources)[index];
        const auto amount = std::min(source->remaining(), remainingConsumed);
        source->position(source->position() + amount);
        remainingConsumed -= amount;
    }
    return wrapped;
}

::jxx::Ptr<SSLEngineResult> OpenSslEngine::unwrap(
    const ::jxx::Ptr<::jxx::nio::ByteBuffer>& source,
    const ::jxx::Ptr<ByteBufferArray>& destinations,
    ::jxx::lang::jint offset,
    ::jxx::lang::jint length) {
    if (source == nullptr || destinations == nullptr)
        throw ::jxx::lang::NullPointerException();
    if (offset < 0 || length < 0 || offset > destinations->length - length)
        throw ::jxx::lang::IllegalArgumentException();

    ::jxx::lang::jint total = 0;
    for (::jxx::lang::jint index = offset; index < offset + length; ++index) {
        const auto destination = (*destinations)[index];
        if (destination == nullptr) throw ::jxx::lang::NullPointerException();
        if (destination->isReadOnly())
            throw ::jxx::lang::IllegalArgumentException(
                "destination buffer is read-only");
        total += destination->remaining();
    }

    const auto scattered = ::jxx::nio::ByteBuffer::allocate(total);
    const auto unwrapped = unwrap(source, scattered);
    scattered->flip();
    auto remainingProduced = unwrapped->bytesProduced();
    for (::jxx::lang::jint index = offset;
         index < offset + length && remainingProduced > 0;
         ++index) {
        const auto destination = (*destinations)[index];
        const auto amount = std::min(
            destination->remaining(), remainingProduced);
        for (::jxx::lang::jint cursor = 0; cursor < amount; ++cursor)
            destination->put(scattered->get());
        remainingProduced -= amount;
    }
    return unwrapped;
}

void OpenSslEngine::closeOutbound() {
    ensureInitialized();
    if (outboundDone_) return;
    SSL_shutdown(ssl_);
    outboundDone_ = true;
    handshakeStatus_ = BIO_ctrl_pending(outboundBio_) > 0
        ? SSLEngineResult::HandshakeStatus::NEED_WRAP
        : SSLEngineResult::HandshakeStatus::NOT_HANDSHAKING;
}

void OpenSslEngine::closeInbound() {
    if (!inboundDone_ && initialized_ && SSL_get_shutdown(ssl_) == 0)
        throw ::jxx::ext::net::ssl::SSLProtocolException(
            "inbound closed before peer close_notify");
    inboundDone_ = true;
}

::jxx::Ptr<::jxx::lang::Runnable> OpenSslEngine::getDelegatedTask() {
    return nullptr;
}

::jxx::Ptr<OpenSslEngine::StringArray>
OpenSslEngine::toArray(const std::vector<std::string>& values) {
    const auto result = ::jxx::NEW<StringArray>(
        static_cast<::jxx::lang::jint>(values.size()));
    for (std::size_t index = 0; index < values.size(); ++index)
        (*result)[static_cast<::jxx::lang::jint>(index)] =
            ::jxx::NEW<::jxx::lang::String>(values[index]);
    return result;
}

std::vector<std::string> OpenSslEngine::toVector(
    const ::jxx::Ptr<StringArray>& values) {
    if (values == nullptr) throw ::jxx::lang::IllegalArgumentException();
    std::vector<std::string> result;
    for (::jxx::lang::jint index = 0; index < values->length; ++index) {
        if ((*values)[index] == nullptr)
            throw ::jxx::lang::IllegalArgumentException();
        result.push_back((*values)[index]->utf8());
    }
    return result;
}

::jxx::Ptr<OpenSslEngine::StringArray>
OpenSslEngine::getSupportedProtocols() const {
    return toArray(supportedProtocolNames());
}

::jxx::Ptr<OpenSslEngine::StringArray>
OpenSslEngine::getEnabledProtocols() const {
    return enabledProtocols_.empty()
        ? getSupportedProtocols()
        : toArray(enabledProtocols_);
}

void OpenSslEngine::setEnabledProtocols(
    const ::jxx::Ptr<StringArray>& protocols) {
    if (handshakeActive_) throw ::jxx::lang::IllegalStateException();
    const auto values = toVector(protocols);
    (void)enabledProtocolRange(values);
    enabledProtocols_ = values;
}

::jxx::Ptr<OpenSslEngine::StringArray>
OpenSslEngine::getSupportedCipherSuites() const {
    return clientMode_
        ? clientSupportedCipherSuites()
        : serverSupportedCipherSuites();
}

::jxx::Ptr<OpenSslEngine::StringArray>
OpenSslEngine::getEnabledCipherSuites() const {
    return enabledCipherSuites_.empty()
        ? getSupportedCipherSuites()
        : toArray(enabledCipherSuites_);
}

void OpenSslEngine::setEnabledCipherSuites(
    const ::jxx::Ptr<StringArray>& suites) {
    if (handshakeActive_) throw ::jxx::lang::IllegalStateException();
    const auto values = toVector(suites);
    validateEnabledCipherSuites(values);
    enabledCipherSuites_ = values;
}

SSLEngineResult::HandshakeStatus
OpenSslEngine::getHandshakeStatus() const {
    return handshakeStatus_;
}

::jxx::Ptr<SSLParameters> OpenSslEngine::getSSLParameters() const {
    const auto parameters = SSLEngine::getSSLParameters();
    parameters->setEndpointIdentificationAlgorithm(
        endpointIdentificationAlgorithm_);
    parameters->setAlgorithmConstraints(
        algorithmConstraints_);
    parameters->setUseCipherSuitesOrder(
        useCipherSuitesOrder_);
    parameters->setSNIMatchers(sniMatchers_);
    if (explicitSniHost_ != nullptr) {
        const auto names = ::jxx::NEW<
            ::jxx::util::ArrayList<::jxx::ext::net::ssl::SNIServerName>>();
        names->add(::jxx::NEW<::jxx::ext::net::ssl::SNIHostName>(
            explicitSniHost_));
        parameters->setServerNames(names);
    }
    return parameters;
}

void OpenSslEngine::setSSLParameters(
    const ::jxx::Ptr<SSLParameters>& parameters) {
    if (handshakeActive_) throw ::jxx::lang::IllegalStateException();
    SSLEngine::setSSLParameters(parameters);
    endpointIdentificationAlgorithm_ =
        parameters->getEndpointIdentificationAlgorithm();
    algorithmConstraints_ =
        parameters->getAlgorithmConstraints();
    useCipherSuitesOrder_ =
        parameters->getUseCipherSuitesOrder();
    sniMatchers_ = parameters->getSNIMatchers();
    if (endpointIdentificationAlgorithm_ != nullptr &&
        !endpointIdentificationAlgorithm_->utf8().empty() &&
        endpointIdentificationAlgorithm_->utf8() != "HTTPS")
        throw ::jxx::lang::IllegalArgumentException(
            "unsupported endpoint identification algorithm");
    explicitSniHost_ = nullptr;
    const auto names = parameters->getServerNames();
    if (names != nullptr) {
        for (::jxx::lang::jint index = 0; index < names->size(); ++index) {
            const auto host = ::jxx::CAST<::jxx::ext::net::ssl::SNIHostName>(
                names->get(index));
            if (host != nullptr) {
                explicitSniHost_ = host->getAsciiName();
                break;
            }
        }
    }
}

::jxx::Ptr<SSLSession> OpenSslEngine::getSession() const {
    return session_;
}

void OpenSslEngine::setUseClientMode(::jxx::lang::jbool mode) {
    if (initialHandshakeStarted_)
        throw ::jxx::lang::IllegalStateException();
    clientMode_ = mode;
}

::jxx::lang::jbool OpenSslEngine::getUseClientMode() const {
    return clientMode_;
}

void OpenSslEngine::setNeedClientAuth(::jxx::lang::jbool need) {
    if (handshakeActive_) throw ::jxx::lang::IllegalStateException();
    needClientAuth_ = need;
    if (need) wantClientAuth_ = false;
}

::jxx::lang::jbool OpenSslEngine::getNeedClientAuth() const {
    return needClientAuth_;
}

void OpenSslEngine::setWantClientAuth(::jxx::lang::jbool want) {
    if (handshakeActive_) throw ::jxx::lang::IllegalStateException();
    wantClientAuth_ = want;
    if (want) needClientAuth_ = false;
}

::jxx::lang::jbool OpenSslEngine::getWantClientAuth() const {
    return wantClientAuth_;
}

void OpenSslEngine::setEnableSessionCreation(::jxx::lang::jbool enabled) {
    if (handshakeActive_) throw ::jxx::lang::IllegalStateException();
    enableSessionCreation_ = enabled;
}

::jxx::lang::jbool OpenSslEngine::getEnableSessionCreation() const {
    return enableSessionCreation_;
}

::jxx::lang::jbool OpenSslEngine::isInboundDone() const {
    return inboundDone_;
}

::jxx::lang::jbool OpenSslEngine::isOutboundDone() const {
    return outboundDone_ &&
        (outboundBio_ == nullptr || BIO_ctrl_pending(outboundBio_) == 0);
}

} // namespace jxx::ext::net::ssl::internal

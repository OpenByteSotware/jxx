#pragma once

#include "lang/jxx.lang.ClassInfo.h"
#include "lang/jxx.lang.Object.h"
#include "io/jxx.io.Reader.h"
#include "io/jxx.io.Writer.h"

namespace com::google::gson::stream
{
	class JsonReader;
	class JsonWriter;
}

namespace com::google::gson {
class JsonElement;

class TypeAdapter
    : public ::jxx::lang::ClassBase<
          TypeAdapter,
          ::jxx::lang::Object> {
public:
    using JxxSuper = ::jxx::lang::Object;
    using Super = ::jxx::lang::ClassBase<TypeAdapter, JxxSuper>;
    using JxxClassInfoMarker = typename Super::JxxClassInfoMarker;

    static ::jxx::Ptr<::jxx::lang::ClassAny> Class() {
        return JxxClassInfoMarker::Class();
    }

    ~TypeAdapter() override = default;

    virtual ::jxx::Ptr<::jxx::lang::Object> fromJsonTree(
        const ::jxx::Ptr<JsonElement>& element) = 0;

    virtual ::jxx::Ptr<JsonElement> toJsonTree(
        const ::jxx::Ptr<::jxx::lang::Object>& value) = 0;

    virtual ::jxx::Ptr<::jxx::lang::Object> read(
        const ::jxx::Ptr<::com::google::gson::stream::JsonReader>& reader);
    virtual void write(
        const ::jxx::Ptr<::com::google::gson::stream::JsonWriter>& writer,
        const ::jxx::Ptr<::jxx::lang::Object>& value);
    ::jxx::Ptr<::jxx::lang::Object> fromJson(
        const ::jxx::Ptr<::jxx::lang::String>& json);
    ::jxx::Ptr<::jxx::lang::String> toJson(
        const ::jxx::Ptr<::jxx::lang::Object>& value);
    ::jxx::Ptr<::jxx::lang::Object> fromJson(
        const ::jxx::Ptr<::jxx::io::Reader>& reader);
    void toJson(
        const ::jxx::Ptr<::jxx::io::Writer>& writer,
        const ::jxx::Ptr<::jxx::lang::Object>& value);
    static ::jxx::Ptr<TypeAdapter> nullSafe(
        const ::jxx::Ptr<TypeAdapter>& delegate);
};

} // namespace com::google::gson

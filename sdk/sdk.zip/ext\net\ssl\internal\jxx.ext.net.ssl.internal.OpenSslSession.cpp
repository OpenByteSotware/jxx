#include <openssl/x509.h>
#include "ext/net/ssl/internal/jxx.ext.net.ssl.internal.OpenSslSession.h"
#include "ext/security/cert/internal/jxx.ext.security.cert.internal.DerX509Certificate.h"
#include "ext/net/ssl/internal/jxx.ext.net.ssl.internal.X509Principal.h"
#include "util/jxx.util.ArrayList.h"
#include "util/jxx.util.UnmodifiableArrayList.h"

#include "ext/net/ssl/jxx.ext.net.ssl.SSLPeerUnverifiedException.h"
#include "ext/net/ssl/jxx.ext.net.ssl.SSLSessionBindingEvent.h"
#include "ext/net/ssl/jxx.ext.net.ssl.SSLSessionBindingListener.h"
#include "lang/jxx.lang.IllegalArgumentException.h"
#include "lang/jxx.lang.NullPointerException.h"

namespace jxx::ext::net::ssl::internal {

namespace {
::jxx::Ptr<OpenSslSession::CertificateArray> copyCertificates(
    const ::jxx::Ptr<OpenSslSession::CertificateArray>& source) {
    if (source == nullptr) return nullptr;
    const auto result = ::jxx::NEW<OpenSslSession::CertificateArray>(
        source->length);
    for (::jxx::lang::jint index = 0; index < source->length; ++index)
        (*result)[index] = (*source)[index];
    return result;
}

::jxx::Ptr<::jxx::security::Principal> certificatePrincipal(
    const ::jxx::Ptr<OpenSslSession::CertificateArray>& certificates) {
    if (certificates == nullptr || certificates->length == 0 ||
        (*certificates)[0] == nullptr) return nullptr;
    const auto encoded = (*certificates)[0]->getEncoded();
    if (encoded == nullptr || encoded->length == 0) return nullptr;
    const unsigned char* cursor = reinterpret_cast<const unsigned char*>(&(*encoded)[0]);
    X509* certificate = d2i_X509(nullptr, &cursor, encoded->length);
    if (certificate == nullptr) return nullptr;
    char* text = X509_NAME_oneline(X509_get_subject_name(certificate), nullptr, 0);
    ::jxx::Ptr<::jxx::security::Principal> result;
    if (text != nullptr) {
        result = ::jxx::NEW<X509Principal>(
            ::jxx::NEW<::jxx::lang::String>(text));
        OPENSSL_free(text);
    }
    X509_free(certificate);
    return result;
}
} // namespace

::jxx::lang::jlong OpenSslSession::nowMillis() {
    return static_cast<::jxx::lang::jlong>(
        std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count());
}

void OpenSslSession::touch() const { lastAccessedTime_ = nowMillis(); }
::jxx::lang::jint OpenSslSession::getApplicationBufferSize() const { touch(); return 16384; }
::jxx::Ptr<::jxx::lang::String> OpenSslSession::getCipherSuite() const { touch(); return cipher_; }
::jxx::lang::jlong OpenSslSession::getCreationTime() const { return creationTime_; }
::jxx::lang::ByteArray OpenSslSession::getId() const { touch(); const auto r=::jxx::NEW<::jxx::lang::JxxArray<::jxx::lang::jbyte,1U>>(id_->length);for(::jxx::lang::jint i=0;i<id_->length;++i)(*r)[i]=(*id_)[i];return r; }
::jxx::lang::jlong OpenSslSession::getLastAccessedTime() const { return lastAccessedTime_; }
::jxx::Ptr<OpenSslSession::CertificateArray>
OpenSslSession::getLocalCertificates() const {
    touch();
    return copyCertificates(localCertificates_);
}
::jxx::Ptr<::jxx::security::Principal>
OpenSslSession::getLocalPrincipal() const {
    touch();
    return certificatePrincipal(localCertificates_);
}
::jxx::lang::jint OpenSslSession::getPacketBufferSize() const { touch(); return 16709; }
::jxx::Ptr<OpenSslSession::CertificateArray>
OpenSslSession::getPeerCertificates() const {
    touch();
    if (peerCertificates_ == nullptr)
        throw ::jxx::ext::net::ssl::SSLPeerUnverifiedException(
            "peer not authenticated");
    return copyCertificates(peerCertificates_);
}
::jxx::Ptr<OpenSslSession::LegacyCertificateArray>
OpenSslSession::getPeerCertificateChain() const {
    const auto certificates = getPeerCertificates();
    const auto result = ::jxx::NEW<LegacyCertificateArray>(
        certificates->length);
    for (::jxx::lang::jint index = 0;
         index < certificates->length;
         ++index) {
        if ((*certificates)[index] == nullptr)
            throw ::jxx::ext::net::ssl::SSLPeerUnverifiedException(
                "peer certificate chain contains a null certificate");
        (*result)[index] = ::jxx::CAST<
            ::jxx::ext::security::cert::X509Certificate>(
                ::jxx::NEW<
                    ::jxx::ext::security::cert::internal::DerX509Certificate>(
                        (*certificates)[index]->getEncoded()));
    }
    return result;
}
::jxx::Ptr<::jxx::lang::String> OpenSslSession::getPeerHost() const { touch(); return host_; }
::jxx::lang::jint OpenSslSession::getPeerPort() const { touch(); return port_; }
::jxx::Ptr<::jxx::security::Principal>
OpenSslSession::getPeerPrincipal() const {
    touch();
    const auto principal = certificatePrincipal(peerCertificates_);
    if (principal == nullptr)
        throw ::jxx::ext::net::ssl::SSLPeerUnverifiedException(
            "peer not authenticated");
    return principal;
}
::jxx::Ptr<::jxx::lang::String> OpenSslSession::getProtocol() const { touch(); return protocol_; }
::jxx::Ptr<OpenSslSession::StringArray>
OpenSslSession::getLocalSupportedSignatureAlgorithms() const {
    const auto source = localSignatureAlgorithms_;
    const auto result = ::jxx::NEW<StringArray>(
        source == nullptr ? 0 : source->length);
    if (source != nullptr)
        for (::jxx::lang::jint index = 0; index < source->length; ++index)
            (*result)[index] = (*source)[index];
    return result;
}
::jxx::Ptr<OpenSslSession::StringArray>
OpenSslSession::getPeerSupportedSignatureAlgorithms() const {
    const auto source = peerSignatureAlgorithms_;
    const auto result = ::jxx::NEW<StringArray>(
        source == nullptr ? 0 : source->length);
    if (source != nullptr)
        for (::jxx::lang::jint index = 0; index < source->length; ++index)
            (*result)[index] = (*source)[index];
    return result;
}
::jxx::Ptr<::jxx::util::List<::jxx::ext::net::ssl::SNIServerName>>
OpenSslSession::getRequestedServerNames() const {
    const auto result = ::jxx::NEW<
        ::jxx::util::ArrayList<::jxx::ext::net::ssl::SNIServerName>>();
    if (requestedServerNames_ != nullptr)
        for (::jxx::lang::jint index = 0;
             index < requestedServerNames_->size();
             ++index)
            result->add(requestedServerNames_->get(index));
    return ::jxx::CAST<
        ::jxx::util::List<::jxx::ext::net::ssl::SNIServerName>>(
            ::jxx::NEW<::jxx::util::UnmodifiableArrayList<
                ::jxx::ext::net::ssl::SNIServerName>>(
                    ::jxx::CAST<::jxx::util::List<
                        ::jxx::ext::net::ssl::SNIServerName>>(result)));
}
::jxx::Ptr<::jxx::ext::net::ssl::SSLSessionContext> OpenSslSession::getSessionContext() const { return context_; }
::jxx::Ptr<::jxx::lang::Object> OpenSslSession::getValue(const ::jxx::Ptr<::jxx::lang::String>& name) const {if(name==nullptr)throw ::jxx::lang::IllegalArgumentException();std::lock_guard<std::mutex> l(mutex_);auto i=values_.find(name->utf8());return i==values_.end()?nullptr:i->second;}
::jxx::Ptr<OpenSslSession::StringArray>
OpenSslSession::getValueNames() const {
    std::lock_guard<std::mutex> lock(mutex_);
    const auto result = ::jxx::NEW<StringArray>(
        static_cast<::jxx::lang::jint>(values_.size()));
    ::jxx::lang::jint index = 0;
    for (const auto& value : values_)
        (*result)[index++] = ::jxx::NEW<::jxx::lang::String>(value.first);
    return result;
}

void OpenSslSession::invalidate() {
    std::vector<std::pair<std::string, ::jxx::Ptr<::jxx::lang::Object>>>
        removed;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        if (!valid_) return;
        valid_ = false;
        removed.reserve(values_.size());
        for (const auto& value : values_) removed.push_back(value);
        values_.clear();
    }
    const auto session = ::jxx::CAST<::jxx::ext::net::ssl::SSLSession>(
        thisPtr());
    for (const auto& value : removed) {
        const auto listener = ::jxx::CAST<
            ::jxx::ext::net::ssl::SSLSessionBindingListener>(value.second);
        if (listener != nullptr)
            listener->valueUnbound(
                ::jxx::NEW<::jxx::ext::net::ssl::SSLSessionBindingEvent>(
                    session,
                    ::jxx::NEW<::jxx::lang::String>(value.first)));
    }
}

::jxx::lang::jbool OpenSslSession::isValid() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return valid_;
}

void OpenSslSession::putValue(
    const ::jxx::Ptr<::jxx::lang::String>& name,
    const ::jxx::Ptr<::jxx::lang::Object>& value) {
    if (name == nullptr || value == nullptr)
        throw ::jxx::lang::IllegalArgumentException();
    ::jxx::Ptr<::jxx::lang::Object> old;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        const auto found = values_.find(name->utf8());
        if (found != values_.end()) old = found->second;
        values_[name->utf8()] = value;
    }
    const auto event =
        ::jxx::NEW<::jxx::ext::net::ssl::SSLSessionBindingEvent>(
            ::jxx::CAST<::jxx::ext::net::ssl::SSLSession>(thisPtr()),
            name);
    const auto oldListener = ::jxx::CAST<
        ::jxx::ext::net::ssl::SSLSessionBindingListener>(old);
    if (oldListener != nullptr) oldListener->valueUnbound(event);
    const auto newListener = ::jxx::CAST<
        ::jxx::ext::net::ssl::SSLSessionBindingListener>(value);
    if (newListener != nullptr) newListener->valueBound(event);
}

void OpenSslSession::removeValue(
    const ::jxx::Ptr<::jxx::lang::String>& name) {
    if (name == nullptr) throw ::jxx::lang::IllegalArgumentException();
    ::jxx::Ptr<::jxx::lang::Object> removed;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        const auto found = values_.find(name->utf8());
        if (found == values_.end()) return;
        removed = found->second;
        values_.erase(found);
    }
    const auto listener = ::jxx::CAST<
        ::jxx::ext::net::ssl::SSLSessionBindingListener>(removed);
    if (listener != nullptr)
        listener->valueUnbound(
            ::jxx::NEW<::jxx::ext::net::ssl::SSLSessionBindingEvent>(
                ::jxx::CAST<::jxx::ext::net::ssl::SSLSession>(thisPtr()),
                name));
}


} // namespace jxx::ext::net::ssl::internal

#include <algorithm>
#include <thread>
#include <string>
#include <vector>
#include <chrono>
#include <thread>
#include <openssl/bio.h>
#include <openssl/err.h>
#include <openssl/rand.h>
#include <openssl/ssl.h>
#include <openssl/x509.h>

#include "ext/net/ssl/internal/jxx.ext.net.ssl.internal.OpenSslContextConfig.h"
#include "ext/net/ssl/internal/jxx.ext.net.ssl.internal.OpenSslCipherSuites.h"
#include "ext/net/ssl/internal/jxx.ext.net.ssl.internal.LayeredSocketBio.h"
#include "ext/net/ssl/internal/jxx.ext.net.ssl.internal.OpenSslSocket.h"
#include "net/jxx.net.SocketTimeoutException.h"
#include "ext/net/ssl/internal/jxx.ext.net.ssl.internal.OpenSslSocketNative.h"
#include "ext/net/ssl/internal/jxx.ext.net.ssl.internal.OpenSslManagerBridge.h"
#include "ext/net/ssl/internal/jxx.ext.net.ssl.internal.OpenSslSniMatcher.h"
#include "ext/net/ssl/internal/jxx.ext.net.ssl.internal.OpenSslProtocolPolicy.h"
#include "ext/net/ssl/internal/jxx.ext.net.ssl.internal.OpenSslPeerIdentity.h"
#include "ext/net/ssl/internal/jxx.ext.net.ssl.internal.OpenSslSession.h"
#include "ext/net/ssl/internal/jxx.ext.net.ssl.internal.OpenSslSignatureAlgorithms.h"
#include "ext/net/ssl/internal/jxx.ext.net.ssl.internal.OpenSslSessionContext.h"
#include "ext/net/ssl/internal/jxx.ext.net.ssl.internal.OpenSslServerSessionCache.h"
#include "ext/net/ssl/internal/jxx.ext.net.ssl.internal.OpenSslStreams.h"
#include "ext/net/ssl/internal/jxx.ext.net.ssl.internal.OpenSslX509Certificate.h"
#include "ext/net/ssl/jxx.ext.net.ssl.HandshakeCompletedEvent.h"
#include "ext/net/ssl/jxx.ext.net.ssl.HandshakeCompletedListener.h"
#include "ext/net/ssl/internal/jxx.ext.net.ssl.internal.HandshakeNotificationTask.h"
#include "lang/jxx.lang.Thread.h"
#include "ext/net/ssl/jxx.ext.net.ssl.SSLException.h"
#include "ext/net/ssl/jxx.ext.net.ssl.SSLHandshakeException.h"
#include "ext/net/ssl/jxx.ext.net.ssl.SSLProtocolException.h"
#include "io/jxx.io.IOException.h"
#include "lang/jxx.lang.IllegalArgumentException.h"
#include "lang/jxx.lang.IllegalStateException.h"
#include "lang/jxx.lang.NullPointerException.h"
#include "lang/jxx.lang.UnsupportedOperationException.h"
#include "security/jxx.security.SecureRandom.h"
#include "net/jxx.net.Socket.h"
#include "net/jxx.net.InetSocketAddress.h"
#include "net/internal/jxx.net.internal.NetPlatform.h"

namespace jxx::ext::net::ssl::internal {
namespace {
std::vector<std::string> toVector(const ::jxx::Ptr<OpenSslSocket::StringArray>& v) {
    if (v == nullptr) throw ::jxx::lang::IllegalArgumentException();
    std::vector<std::string> r;
    r.reserve(static_cast<std::size_t>(v->length));
    for (::jxx::lang::jint i = 0; i < v->length; ++i) {
        if ((*v)[i] == nullptr) throw ::jxx::lang::IllegalArgumentException();
        r.push_back((*v)[i]->utf8());
    }
    return r;
}
::jxx::Ptr<OpenSslSocket::StringArray> toArray(const std::vector<std::string>& v) {
    auto r = ::jxx::NEW<OpenSslSocket::StringArray>(static_cast<::jxx::lang::jint>(v.size()));
    for (std::size_t i = 0; i < v.size(); ++i)
        (*r)[static_cast<::jxx::lang::jint>(i)] = ::jxx::NEW<::jxx::lang::String>(v[i]);
    return r;
}
std::string join(const std::vector<std::string>& v) {
    std::string r;
    for (const auto& s : v) { if (!r.empty()) r.push_back(':'); r += s; }
    return r;
}
std::string tlsFailureMessage(
    SSL* ssl,
    int sslError,
    const char* message) {
    std::string detail = message == nullptr
        ? std::string("TLS operation failed")
        : std::string(message);
    detail += " [SSL_get_error=" + std::to_string(sslError) + "]";

    if (ssl != nullptr) {
        const long verifyResult = SSL_get_verify_result(ssl);
        if (verifyResult != X509_V_OK) {
            const char* verifyText =
                X509_verify_cert_error_string(verifyResult);
            detail += " [verify=" + std::to_string(verifyResult);
            if (verifyText != nullptr && *verifyText != '\0') {
                detail += ": ";
                detail += verifyText;
            }
            detail += "]";
        }
    }

    bool firstOpenSslError = true;
    for (;;) {
        const unsigned long code = ERR_get_error();
        if (code == 0UL) break;
        char buffer[256] = {};
        ERR_error_string_n(code, buffer, sizeof(buffer));
        detail += firstOpenSslError
            ? " [OpenSSL: "
            : "; ";
        detail += buffer;
        firstOpenSslError = false;
    }
    if (!firstOpenSslError) detail += "]";
    return detail;
}

[[noreturn]] void throwTlsFailure(
    SSL* ssl,
    int operation,
    const char* message,
    bool handshake = false) {
    const int error = ssl == nullptr
        ? SSL_ERROR_SSL
        : SSL_get_error(ssl, operation);
    const auto detail = tlsFailureMessage(ssl, error, message);
    switch (error) {
    case SSL_ERROR_SSL:
        if (handshake)
            throw ::jxx::ext::net::ssl::SSLHandshakeException(detail.c_str());
        throw ::jxx::ext::net::ssl::SSLProtocolException(detail.c_str());
    case SSL_ERROR_SYSCALL:
        throw ::jxx::ext::net::ssl::SSLException(detail.c_str());
    case SSL_ERROR_ZERO_RETURN:
        throw ::jxx::ext::net::ssl::SSLException("TLS peer closed the connection");
    case SSL_ERROR_WANT_READ:
    case SSL_ERROR_WANT_WRITE:
        throw ::jxx::ext::net::ssl::SSLException("TLS operation requires additional I/O");
    default:
        throw ::jxx::ext::net::ssl::SSLException(detail.c_str());
    }
}

}

OpenSslSocket::OpenSslSocket(const std::shared_ptr<OpenSslContextConfig>& config)
    : config_(config), native_(new OpenSslSocketNative()),
      host_(::jxx::NEW<::jxx::lang::String>("")),
      enabledProtocols_(contextProtocolNames(config == nullptr ? nullptr : config->protocol)) {}

OpenSslSocket::OpenSslSocket(const ::jxx::Ptr<::jxx::lang::String>& h,
    ::jxx::lang::jint p, const std::shared_ptr<OpenSslContextConfig>& config)
    : config_(config), native_(new OpenSslSocketNative()), host_(h), port_(p),
      enabledProtocols_(contextProtocolNames(config == nullptr ? nullptr : config->protocol)) {
    if (h == nullptr) throw ::jxx::lang::NullPointerException();
    if (p < 0 || p > 65535) throw ::jxx::lang::IllegalArgumentException();
    transport_ = ::jxx::NEW<::jxx::net::Socket>(h, p);
    connected_ = true;
}

OpenSslSocket::OpenSslSocket(const ::jxx::Ptr<::jxx::net::Socket>& transport,
    const ::jxx::Ptr<::jxx::lang::String>& host, ::jxx::lang::jint port,
    ::jxx::lang::jbool autoClose, const std::vector<unsigned char>& consumed,
    const std::shared_ptr<OpenSslContextConfig>& config)
    : config_(config), native_(new OpenSslSocketNative()), host_(host), port_(port),
      transport_(transport), autoClose_(autoClose), consumed_(consumed),
      enabledProtocols_(contextProtocolNames(config == nullptr ? nullptr : config->protocol)) {
    if (transport_ == nullptr || host_ == nullptr) throw ::jxx::lang::IllegalArgumentException();
    connected_ = transport_->isConnected();
    soTimeout_ = transport_->getSoTimeout();
}

OpenSslSocket::~OpenSslSocket() = default;

::jxx::Ptr<::jxx::net::InetAddress>
OpenSslSocket::getInetAddress() const {
    return transport_ != nullptr
        ? transport_->getInetAddress()
        : ::jxx::net::Socket::getInetAddress();
}

::jxx::Ptr<::jxx::net::InetAddress>
OpenSslSocket::getLocalAddress() const {
    return transport_ != nullptr
        ? transport_->getLocalAddress()
        : ::jxx::net::Socket::getLocalAddress();
}

::jxx::lang::jint OpenSslSocket::getPort() const noexcept {
    return transport_ != nullptr
        ? transport_->getPort()
        : ::jxx::net::Socket::getPort();
}

::jxx::lang::jint OpenSslSocket::getLocalPort() const noexcept {
    return transport_ != nullptr
        ? transport_->getLocalPort()
        : ::jxx::net::Socket::getLocalPort();
}

::jxx::Ptr<::jxx::net::SocketAddress>
OpenSslSocket::getRemoteSocketAddress() const {
    return transport_ != nullptr
        ? transport_->getRemoteSocketAddress()
        : ::jxx::net::Socket::getRemoteSocketAddress();
}

::jxx::Ptr<::jxx::net::SocketAddress>
OpenSslSocket::getLocalSocketAddress() const {
    return transport_ != nullptr
        ? transport_->getLocalSocketAddress()
        : ::jxx::net::Socket::getLocalSocketAddress();
}

void OpenSslSocket::startHandshake() {
    std::lock_guard<std::recursive_mutex> tlsLock(tlsMutex_);
    if (closed_)
        throw ::jxx::io::IOException("SSL socket is closed");
    if (session_ != nullptr) return;
    handshakeInProgress_ = true;
    const auto resetHandshakeState = [this]() {
        handshakeSession_ = nullptr;
        handshakeInProgress_ = false;
    };
    const std::shared_ptr<void> handshakeStateGuard(
        nullptr,
        [resetHandshakeState](void*) {
            resetHandshakeState();
        });

    const auto handshakeContext =
        client_
            ? config_->clientSessionContext
            : config_->serverSessionContext;

    handshakeSession_ = ::jxx::NEW<OpenSslSession>(
        ::jxx::NEW<::jxx::lang::String>(
            "SSL_NULL_WITH_NULL_NULL"),
        ::jxx::NEW<::jxx::lang::String>(
            "NONE"),
        host_,
        port_,
        nullptr,
        nullptr,
        ::jxx::NEW<
            ::jxx::lang::JxxArray<
                ::jxx::lang::jbyte,
                1U>>(0),
        handshakeContext);
    if (!connected_ || transport_ == nullptr)
        throw ::jxx::lang::IllegalStateException("SSL socket is not connected");
    bool handshakeSucceeded = false;
    const std::shared_ptr<void> failedHandshakeGuard(
        nullptr,
        [this, &handshakeSucceeded](void*) noexcept {
            if (handshakeSucceeded) return;
            try {
                close();
            } catch (...) {
                closed_ = true;
                session_ = nullptr;
                handshakeSession_ = nullptr;
                handshakeInProgress_ = false;
            }
        });

    native_->context = SSL_CTX_new(client_ ? TLS_client_method() : TLS_server_method());
    if (native_->context == nullptr) throw ::jxx::io::IOException("SSL_CTX_new failed");
    const auto configuredRange = protocolRange(
        config_ == nullptr ? nullptr : config_->protocol);
    int minv = configuredRange.first;
    int maxv = configuredRange.second;
    if (!enabledProtocols_.empty()) {
        const auto enabledRange = enabledProtocolRange(enabledProtocols_);
        minv = enabledRange.first;
        maxv = enabledRange.second;
    }
    if (SSL_CTX_set_min_proto_version(native_->context, minv) != 1 ||
        SSL_CTX_set_max_proto_version(native_->context, maxv) != 1)
        throw ::jxx::io::IOException("Could not apply enabled TLS protocols");
    if (!enabledProtocols_.empty()) {
        const auto containsProtocol = [this](const char* value) {
            return std::find(
                enabledProtocols_.begin(),
                enabledProtocols_.end(),
                std::string(value)) != enabledProtocols_.end();
        };
        unsigned long disabled = 0UL;
#ifdef SSL_OP_NO_TLSv1
        if (!containsProtocol("TLSv1")) disabled |= SSL_OP_NO_TLSv1;
#endif
#ifdef SSL_OP_NO_TLSv1_1
        if (!containsProtocol("TLSv1.1")) disabled |= SSL_OP_NO_TLSv1_1;
#endif
#ifdef SSL_OP_NO_TLSv1_2
        if (!containsProtocol("TLSv1.2")) disabled |= SSL_OP_NO_TLSv1_2;
#endif
#ifdef SSL_OP_NO_TLSv1_3
        if (!containsProtocol("TLSv1.3")) disabled |= SSL_OP_NO_TLSv1_3;
#endif
        if (disabled != 0UL) SSL_CTX_set_options(native_->context, disabled);
    }
    if (!enabledCipherSuites_.empty())
        applyEnabledCipherSuites(native_->context, enabledCipherSuites_);
    if (!client_ && useCipherSuitesOrder_)
        SSL_CTX_set_options(
            native_->context,
            SSL_OP_CIPHER_SERVER_PREFERENCE);
    if (config_ != nullptr && config_->secureRandom != nullptr) {
        auto seed = ::jxx::NEW<::jxx::lang::JxxArray<::jxx::lang::jbyte, 1U>>(64);
        config_->secureRandom->nextBytes(seed);
        RAND_seed(&(*seed)[0], seed->length);
    }
    int verify = SSL_VERIFY_PEER;
    if (!client_ && need_) verify |= SSL_VERIFY_FAIL_IF_NO_PEER_CERT;
    if (!client_ && !need_ && !want_) verify = SSL_VERIFY_NONE;
    SSL_CTX_set_verify(native_->context, verify, nullptr);
    if (SSL_CTX_set_default_verify_paths(native_->context) != 1)
        throw ::jxx::io::IOException("Could not load default trust paths");
    if (!client_ && config_ != nullptr && config_->serverSessionContext != nullptr)
        configureServerSessionCache(
            native_->context, config_->serverSessionContext.get());
    if (!client_ && !create_) {
        SSL_CTX_set_session_cache_mode(native_->context, SSL_SESS_CACHE_OFF);
        SSL_CTX_set_options(native_->context, SSL_OP_NO_TICKET);
    }
    native_->managerBridge = std::make_unique<OpenSslManagerBridge>(config_, algorithmConstraints_);
    SSL_CTX_set_cert_verify_callback(native_->context, openSslVerifyCallback, native_->managerBridge.get());
    SSL_CTX_set_client_cert_cb(native_->context, openSslClientCertificateCallback);
    if (!client_) configureServerNameMatchers(native_->context, sniMatchers_);
    SSL* ssl = SSL_new(native_->context);
    if (ssl == nullptr)
        throw ::jxx::io::IOException("SSL_new failed");
    if (transport_ != nullptr) {
        const auto handle = transport_->nativeSocketHandle();
        if (handle == ::jxx::net::internal::kInvalidSocket) {
            SSL_free(ssl);
            throw ::jxx::io::IOException("layered socket has no native transport");
        }
        BIO* socketBio = createLayeredSocketBio(
            handle,
            consumed_);
        if (socketBio == nullptr) {
            SSL_free(ssl);
            throw ::jxx::io::IOException(
                "layered socket BIO allocation failed");
        }
        SSL_set_bio(ssl, socketBio, socketBio);
        native_->connection = BIO_new(BIO_f_ssl());
        if (native_->connection == nullptr) {
            SSL_free(ssl);
            throw ::jxx::io::IOException("BIO_f_ssl allocation failed");
        }
        BIO_set_ssl(native_->connection, ssl, BIO_CLOSE);
    } else {
        native_->connection = BIO_new_ssl_connect(native_->context);
        if (native_->connection == nullptr) {
            SSL_free(ssl);
            throw ::jxx::io::IOException("BIO_new_ssl_connect failed");
        }
        BIO_get_ssl(native_->connection, &ssl);
        const std::string endpoint = host_->utf8() + ":" + std::to_string(port_);
        BIO_set_conn_hostname(native_->connection, endpoint.c_str());
    }
    SSL_set_ex_data(ssl, openSslManagerBridgeExDataIndex(), native_->managerBridge.get());
    if (client_ && config_ != nullptr && config_->clientSessionContext != nullptr) {
        SSL_SESSION* cached = config_->clientSessionContext->acquireNativeSession(
            host_, port_);
        if (cached != nullptr) {
            const int applied = SSL_set_session(ssl, cached);
            SSL_SESSION_free(cached);
            if (applied != 1)
                throw ::jxx::io::IOException("Could not apply cached TLS session");
        }
    }
    if (client_) {
        SSL_set_connect_state(ssl);
        const auto tlsHost = sniHost_ != nullptr ? sniHost_ : host_;
        if (tlsHost != nullptr && !tlsHost->utf8().empty() &&
            SSL_set_tlsext_host_name(ssl, tlsHost->utf8().c_str()) != 1)
            throw ::jxx::ext::net::ssl::SSLProtocolException(
                "could not configure SNI host");
        if (endpointIdentificationAlgorithm_ != nullptr &&
            endpointIdentificationAlgorithm_->utf8() == "HTTPS") {
            configureHttpsEndpointIdentification(ssl, host_);
        }
    } else {
        SSL_set_accept_state(ssl);
        if (native_->managerBridge->selectServerIdentity(ssl) != 1)
            throw ::jxx::io::IOException("No usable server certificate identity");
    }
    if (transport_ == nullptr && client_) {
        const int connectResult = BIO_do_connect(native_->connection);
        if (connectResult <= 0) {
            close();
            throw ::jxx::ext::net::ssl::SSLException("TLS transport connect failed");
        }
    }
    const auto handshakeStarted = std::chrono::steady_clock::now();
    for (;;) {
        const int handshakeResult =
            BIO_do_handshake(native_->connection);
        if (handshakeResult > 0) break;

        SSL* failedSsl = nullptr;
        BIO_get_ssl(native_->connection, &failedSsl);
        const int error = failedSsl == nullptr
            ? SSL_ERROR_SSL
            : SSL_get_error(failedSsl, handshakeResult);

        if (error == SSL_ERROR_WANT_READ ||
            error == SSL_ERROR_WANT_WRITE)
        {
            if (soTimeout_ > 0) {
                const auto elapsed =
                    std::chrono::duration_cast<std::chrono::milliseconds>(
                        std::chrono::steady_clock::now() -
                        handshakeStarted).count();
                if (elapsed >= soTimeout_) {
                    close();
                    throw ::jxx::net::SocketTimeoutException(
                        "TLS handshake timed out");
                }
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
            continue;
        }

        if (soTimeout_ > 0) {
            const auto elapsed =
                std::chrono::duration_cast<std::chrono::milliseconds>(
                    std::chrono::steady_clock::now() -
                    handshakeStarted).count();
            if (elapsed >= soTimeout_) {
                close();
                throw ::jxx::net::SocketTimeoutException(
                    "TLS handshake timed out");
            }
        }

        try {
            throwTlsFailure(
                failedSsl,
                handshakeResult,
                "TLS handshake failed",
                true);
        } catch (const ::jxx::ext::net::ssl::SSLException&) {
            close();
            throw;
        }
    }
    if (!create_ && SSL_session_reused(ssl) != 1)
        throw ::jxx::ext::net::ssl::SSLHandshakeException(
            "session creation is disabled");

    SSL_SESSION* ns = SSL_get_session(ssl);
    if (client_ && ns != nullptr && config_ != nullptr &&
        config_->clientSessionContext != nullptr)
        config_->clientSessionContext->registerNativeSession(host_, port_, ns);
    unsigned int idn = 0;
    const unsigned char* id = ns == nullptr ? nullptr : SSL_SESSION_get_id(ns, &idn);
    auto sid = ::jxx::NEW<::jxx::lang::JxxArray<::jxx::lang::jbyte, 1U>>(static_cast<::jxx::lang::jint>(idn));
    for (unsigned int i = 0; i < idn; ++i) (*sid)[static_cast<::jxx::lang::jint>(i)] = static_cast<::jxx::lang::jbyte>(id[i]);
    auto sc = client_ ? config_->clientSessionContext : config_->serverSessionContext;
    using CA = OpenSslSession::CertificateArray; ::jxx::Ptr<CA> locals;
    const auto peers = peerCertificateChain(ssl);
    X509* local = SSL_get_certificate(ssl);
    if (local != nullptr) {
        int len = i2d_X509(local, nullptr); locals = ::jxx::NEW<CA>(1);
        auto enc = ::jxx::NEW<::jxx::lang::JxxArray<::jxx::lang::jbyte, 1U>>(len);
        unsigned char* cur = reinterpret_cast<unsigned char*>(&(*enc)[0]);
        if (len <= 0 || i2d_X509(local, &cur) != len) throw ::jxx::io::IOException("Could not encode local certificate");
        (*locals)[0] = ::jxx::CAST<::jxx::security::cert::Certificate>(::jxx::NEW<OpenSslX509Certificate>(enc));
    }
    session_ = ::jxx::NEW<OpenSslSession>(::jxx::NEW<::jxx::lang::String>(SSL_get_cipher_name(ssl)),
        ::jxx::NEW<::jxx::lang::String>(SSL_get_version(ssl)), host_, port_, peers, locals, sid, sc,
        localSupportedSignatureAlgorithms(ssl),
        peerSupportedSignatureAlgorithms(ssl),
        requestedServerNames(ssl));
    if (sc != nullptr) sc->registerSession(session_);
    handshakeSucceeded = true;
    auto self = ::jxx::CAST<::jxx::ext::net::ssl::SSLSocket>(thisPtr());
    if (self == nullptr) throw ::jxx::lang::IllegalStateException("OpenSslSocket has no JXX-managed self reference");
    auto event = ::jxx::NEW<HandshakeCompletedEvent>(self, session_);
    std::vector<::jxx::Ptr<HandshakeCompletedListener>> listeners;
    {
        std::lock_guard<std::mutex> listenerLock(listenerMutex_);
        listeners = listeners_;
    }
    if (!listeners.empty()) {
        const auto notificationTask =
            ::jxx::NEW<HandshakeNotificationTask>(listeners, event);
        const auto notificationThread =
            ::jxx::NEW<::jxx::lang::Thread>(
                ::jxx::CAST<::jxx::lang::Runnable>(notificationTask),
                ::jxx::NEW<::jxx::lang::String>(
                    "HandshakeCompletedNotify-" +
                    host_->utf8() + ":" + std::to_string(port_)));
        notificationThread->setDaemon(true);
        notificationThread->start();
    }
}

::jxx::Ptr<::jxx::io::InputStream>
OpenSslSocket::getInputStream() {
    std::lock_guard<std::recursive_mutex> tlsLock(tlsMutex_);
    if (closed_)
        throw ::jxx::io::IOException("SSL socket is closed");
    if (!connected_)
        throw ::jxx::io::IOException("SSL socket is not connected");
    if (inputStream_ == nullptr)
        inputStream_ = ::jxx::NEW<OpenSslInputStream>(this);
    return inputStream_;
}

::jxx::Ptr<::jxx::io::OutputStream>
OpenSslSocket::getOutputStream() {
    std::lock_guard<std::recursive_mutex> tlsLock(tlsMutex_);
    if (closed_)
        throw ::jxx::io::IOException("SSL socket is closed");
    if (!connected_)
        throw ::jxx::io::IOException("SSL socket is not connected");
    if (outputStream_ == nullptr)
        outputStream_ = ::jxx::NEW<OpenSslOutputStream>(this);
    return outputStream_;
}
void OpenSslSocket::setSoTimeout(::jxx::lang::jint timeout) {
    if (timeout < 0) throw ::jxx::lang::IllegalArgumentException();
    std::lock_guard<std::recursive_mutex> tlsLock(tlsMutex_);
    if (closed_) throw ::jxx::io::IOException("SSL socket is closed");
    soTimeout_ = timeout;
    if (transport_ != nullptr) transport_->setSoTimeout(timeout);
    if (pendingTransport_ != nullptr) pendingTransport_->setSoTimeout(timeout);
}

::jxx::lang::jint OpenSslSocket::getSoTimeout() const noexcept {
    return soTimeout_;
}

::jxx::lang::jbool OpenSslSocket::isConnected() const noexcept {
    return connected_;
}

::jxx::lang::jbool OpenSslSocket::isClosed() const noexcept {
    return closed_;
}

void OpenSslSocket::close() {
    std::lock_guard<std::recursive_mutex> tlsLock(tlsMutex_);
    if (closed_) return;
    if (native_ != nullptr && native_->connection != nullptr) {
        SSL* ssl = nullptr;
        BIO_get_ssl(native_->connection, &ssl);
        if (ssl != nullptr) {
            SSL_shutdown(ssl);
        }
    }
    native_.reset(new OpenSslSocketNative());
    session_ = nullptr;
    inputStream_ = nullptr;
    outputStream_ = nullptr;
    handshakeSession_ = nullptr;
    handshakeInProgress_ = false;
    connected_ = false;
    closed_ = true;
    if (autoClose_ && transport_ != nullptr) transport_->close();
}
int OpenSslSocket::tlsRead(unsigned char* data, int length) {
    std::lock_guard<std::recursive_mutex> tlsLock(tlsMutex_);
    startHandshake();
    const auto started = std::chrono::steady_clock::now();
    for (;;) {
        const int result = BIO_read(native_->connection, data, length);
        if (result > 0) return result;
        SSL* ssl = nullptr;
        BIO_get_ssl(native_->connection, &ssl);
        const int error = ssl == nullptr
            ? SSL_ERROR_SSL
            : SSL_get_error(ssl, result);
        if (error == SSL_ERROR_ZERO_RETURN) {
            connected_ = false;
            return -1;
        }
        if (error == SSL_ERROR_WANT_READ || error == SSL_ERROR_WANT_WRITE) {
            if (soTimeout_ > 0) {
                const auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(
                    std::chrono::steady_clock::now() - started).count();
                if (elapsed >= soTimeout_)
                    throw ::jxx::net::SocketTimeoutException("TLS read timed out");
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
            continue;
        }
        throwTlsFailure(ssl, result, "TLS read failed");
    }
}

int OpenSslSocket::tlsWrite(const unsigned char* data, int length) {
    std::lock_guard<std::recursive_mutex> tlsLock(tlsMutex_);
    startHandshake();
    int written = 0;
    while (written < length) {
        const int result = BIO_write(
            native_->connection,
            data + written,
            length - written);
        if (result > 0) {
            written += result;
            continue;
        }
        SSL* ssl = nullptr;
        BIO_get_ssl(native_->connection, &ssl);
        const int error = ssl == nullptr
            ? SSL_ERROR_SSL
            : SSL_get_error(ssl, result);
        if (error == SSL_ERROR_WANT_READ ||
            error == SSL_ERROR_WANT_WRITE) {
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
            continue;
        }
        throwTlsFailure(ssl, result, "TLS write failed");
    }
    return written;
}
::jxx::Ptr<OpenSslSocket::StringArray> OpenSslSocket::getSupportedProtocols()const{return toArray(supportedProtocolNames());}
::jxx::Ptr<OpenSslSocket::StringArray> OpenSslSocket::getEnabledProtocols()const{return enabledProtocols_.empty()?getSupportedProtocols():toArray(enabledProtocols_);}
void OpenSslSocket::setEnabledProtocols(const ::jxx::Ptr<StringArray>&v){if(session_!=nullptr)throw ::jxx::lang::IllegalStateException();const auto values=toVector(v);(void)enabledProtocolRange(values);enabledProtocols_=values;}
::jxx::Ptr<OpenSslSocket::StringArray>
OpenSslSocket::getSupportedCipherSuites() const {
    return client_
        ? clientSupportedCipherSuites()
        : serverSupportedCipherSuites();
}
::jxx::Ptr<OpenSslSocket::StringArray> OpenSslSocket::getEnabledCipherSuites()const{return enabledCipherSuites_.empty()?getSupportedCipherSuites():toArray(enabledCipherSuites_);}
void OpenSslSocket::setEnabledCipherSuites(
    const ::jxx::Ptr<StringArray>& values) {
    if (session_ != nullptr || handshakeInProgress_)
        throw ::jxx::lang::IllegalStateException();
    const auto suites = toVector(values);
    validateEnabledCipherSuites(suites);
    enabledCipherSuites_ = suites;
}
::jxx::Ptr<OpenSslSocket::SSLSession> OpenSslSocket::getSession(){startHandshake();return session_;}
::jxx::Ptr<OpenSslSocket::SSLSession>
OpenSslSocket::getHandshakeSession() const {
    std::lock_guard<std::recursive_mutex> tlsLock(tlsMutex_);
    return handshakeInProgress_
        ? handshakeSession_
        : nullptr;
}
void OpenSslSocket::addHandshakeCompletedListener(
    const ::jxx::Ptr<HandshakeCompletedListener>& listener) {
    if (listener == nullptr)
        throw ::jxx::lang::IllegalArgumentException();
    std::lock_guard<std::mutex> listenerLock(listenerMutex_);
    listeners_.push_back(listener);
}
void OpenSslSocket::removeHandshakeCompletedListener(
    const ::jxx::Ptr<HandshakeCompletedListener>& listener) {
    if (listener == nullptr)
        throw ::jxx::lang::IllegalArgumentException();
    std::lock_guard<std::mutex> listenerLock(listenerMutex_);
    const auto found = std::find(listeners_.begin(), listeners_.end(), listener);
    if (found == listeners_.end())
        throw ::jxx::lang::IllegalArgumentException();
    listeners_.erase(found);
}
void OpenSslSocket::setUseClientMode(::jxx::lang::jbool v){if(session_!=nullptr)throw ::jxx::lang::IllegalStateException();client_=v;}
::jxx::lang::jbool OpenSslSocket::getUseClientMode()const{return client_;}
void OpenSslSocket::setNeedClientAuth(::jxx::lang::jbool v){if(session_!=nullptr)throw ::jxx::lang::IllegalStateException();need_=v;if(v)want_=false;}
::jxx::lang::jbool OpenSslSocket::getNeedClientAuth()const{return need_;}
void OpenSslSocket::setWantClientAuth(::jxx::lang::jbool v){if(session_!=nullptr)throw ::jxx::lang::IllegalStateException();want_=v;if(v)need_=false;}
::jxx::lang::jbool OpenSslSocket::getWantClientAuth()const{return want_;}
void OpenSslSocket::setEnableSessionCreation(::jxx::lang::jbool v){if(session_!=nullptr)throw ::jxx::lang::IllegalStateException();create_=v;}
::jxx::lang::jbool OpenSslSocket::getEnableSessionCreation()const{return create_;}
} // namespace jxx::ext::net::ssl::internal

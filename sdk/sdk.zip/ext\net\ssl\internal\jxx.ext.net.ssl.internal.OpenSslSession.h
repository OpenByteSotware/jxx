#pragma once

#include <chrono>
#include <mutex>
#include <string>
#include <unordered_map>

#include "ext/net/ssl/jxx.ext.net.ssl.ExtendedSSLSession.h"
#include "ext/net/ssl/jxx.ext.net.ssl.SNIServerName.h"
#include "util/jxx.util.List.h"

namespace jxx::ext::net::ssl::internal {

class OpenSslSession final
    : public ::jxx::lang::ClassBase<
          OpenSslSession,
          ::jxx::ext::net::ssl::ExtendedSSLSession> {
public:
    using JxxSuper = ::jxx::ext::net::ssl::ExtendedSSLSession;
    using Super = ::jxx::lang::ClassBase<OpenSslSession, JxxSuper>;
    using CertificateArray = SSLSession::CertificateArray;
    using StringArray = SSLSession::StringArray;
    using LegacyCertificateArray = SSLSession::LegacyCertificateArray;

    OpenSslSession(
        const ::jxx::Ptr<::jxx::lang::String>& cipher,
        const ::jxx::Ptr<::jxx::lang::String>& protocol,
        const ::jxx::Ptr<::jxx::lang::String>& host,
        ::jxx::lang::jint port,
        const ::jxx::Ptr<CertificateArray>& peerCertificates = nullptr,
        const ::jxx::Ptr<CertificateArray>& localCertificates = nullptr,
        const ::jxx::lang::ByteArray& id = nullptr,
        const ::jxx::Ptr<::jxx::ext::net::ssl::SSLSessionContext>& context = nullptr,
        const ::jxx::Ptr<StringArray>& localSignatureAlgorithms = nullptr,
        const ::jxx::Ptr<StringArray>& peerSignatureAlgorithms = nullptr,
        const ::jxx::Ptr<::jxx::util::List<
            ::jxx::ext::net::ssl::SNIServerName>>& requestedServerNames = nullptr)
        : cipher_(cipher)
        , protocol_(protocol)
        , host_(host)
        , port_(port)
        , peerCertificates_(peerCertificates)
        , localCertificates_(localCertificates)
        , id_(id == nullptr
              ? ::jxx::NEW<::jxx::lang::JxxArray<
                    ::jxx::lang::jbyte, 1U>>(0)
              : id)
        , context_(context)
        , localSignatureAlgorithms_(localSignatureAlgorithms)
        , peerSignatureAlgorithms_(peerSignatureAlgorithms)
        , requestedServerNames_(requestedServerNames)
        , creationTime_(nowMillis())
        , lastAccessedTime_(creationTime_) {
    }

    ::jxx::lang::jint getApplicationBufferSize() const override;
    ::jxx::Ptr<::jxx::lang::String> getCipherSuite() const override;
    ::jxx::lang::jlong getCreationTime() const override;
    ::jxx::lang::ByteArray getId() const override;
    ::jxx::lang::jlong getLastAccessedTime() const override;
    ::jxx::Ptr<CertificateArray> getLocalCertificates() const override;
    ::jxx::Ptr<::jxx::security::Principal> getLocalPrincipal() const override;
    ::jxx::lang::jint getPacketBufferSize() const override;
    ::jxx::Ptr<CertificateArray> getPeerCertificates() const override;
    ::jxx::Ptr<LegacyCertificateArray>
    getPeerCertificateChain() const override;
    ::jxx::Ptr<::jxx::lang::String> getPeerHost() const override;
    ::jxx::lang::jint getPeerPort() const override;
    ::jxx::Ptr<::jxx::security::Principal> getPeerPrincipal() const override;
    ::jxx::Ptr<::jxx::lang::String> getProtocol() const override;
    ::jxx::Ptr<StringArray> getLocalSupportedSignatureAlgorithms() const override;
    ::jxx::Ptr<StringArray> getPeerSupportedSignatureAlgorithms() const override;
    ::jxx::Ptr<::jxx::util::List<::jxx::ext::net::ssl::SNIServerName>>
    getRequestedServerNames() const override;
    ::jxx::Ptr<::jxx::ext::net::ssl::SSLSessionContext>
    getSessionContext() const override;
    ::jxx::Ptr<::jxx::lang::Object> getValue(
        const ::jxx::Ptr<::jxx::lang::String>& name) const override;
    ::jxx::Ptr<StringArray> getValueNames() const override;
    void invalidate() override;
    ::jxx::lang::jbool isValid() const override;
    void putValue(
        const ::jxx::Ptr<::jxx::lang::String>& name,
        const ::jxx::Ptr<::jxx::lang::Object>& value) override;
    void removeValue(
        const ::jxx::Ptr<::jxx::lang::String>& name) override;

private:
    static ::jxx::lang::jlong nowMillis();
    void touch() const;

    ::jxx::Ptr<::jxx::lang::String> cipher_;
    ::jxx::Ptr<::jxx::lang::String> protocol_;
    ::jxx::Ptr<::jxx::lang::String> host_;
    ::jxx::lang::jint port_;
    ::jxx::Ptr<CertificateArray> peerCertificates_;
    ::jxx::Ptr<CertificateArray> localCertificates_;
    ::jxx::lang::ByteArray id_;
    ::jxx::Ptr<::jxx::ext::net::ssl::SSLSessionContext> context_;
    ::jxx::Ptr<StringArray> localSignatureAlgorithms_;
    ::jxx::Ptr<StringArray> peerSignatureAlgorithms_;
    ::jxx::Ptr<::jxx::util::List<
        ::jxx::ext::net::ssl::SNIServerName>> requestedServerNames_;
    ::jxx::lang::jlong creationTime_;
    mutable ::jxx::lang::jlong lastAccessedTime_;
    ::jxx::lang::jbool valid_ = true;
    mutable std::mutex mutex_;
    std::unordered_map<std::string, ::jxx::Ptr<::jxx::lang::Object>> values_;
};

} // namespace jxx::ext::net::ssl::internal

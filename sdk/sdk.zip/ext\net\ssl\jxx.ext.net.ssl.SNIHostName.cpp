#include "ext/net/ssl/jxx.ext.net.ssl.SNIHostName.h"
#include "lang/jxx.lang.IllegalArgumentException.h"
#include "lang/jxx.lang.NullPointerException.h"
namespace jxx::ext::net::ssl
{
	namespace
	{
		::jxx::lang::ByteArray bytes(const ::jxx::Ptr<::jxx::lang::String>& s)
		{
			if (s == nullptr)throw ::jxx::lang::NullPointerException(); auto v = s->utf8(); if (v.empty())throw ::jxx::lang::IllegalArgumentException(); auto r = ::jxx::NEW<::jxx::lang::JxxArray<::jxx::lang::jbyte, 1U>>(static_cast<::jxx::lang::jint>(v.size())); for (std::size_t i = 0; i < v.size(); ++i)(*r)[static_cast<::jxx::lang::jint>(i)] = static_cast<::jxx::lang::jbyte>(v[i]); return r;
		}::jxx::Ptr<::jxx::lang::String> text(const ::jxx::lang::ByteArray& b)
		{
			if (b == nullptr)throw ::jxx::lang::NullPointerException(); std::string v; for (::jxx::lang::jint i = 0; i < b->length; ++i)v.push_back(static_cast<char>((*b)[i])); if (v.empty())throw ::jxx::lang::IllegalArgumentException(); return ::jxx::NEW<::jxx::lang::String>(v);
		}
	}SNIHostName::SNIHostName(const ::jxx::Ptr<::jxx::lang::String>& h) :Super(0, bytes(h)), hostname_(h)
	{
	}SNIHostName::SNIHostName(const ::jxx::lang::ByteArray& e) :Super(0, e), hostname_(text(e))
	{
	}::jxx::Ptr<::jxx::lang::String>SNIHostName::getAsciiName()const
	{
		return hostname_;
	}
}
